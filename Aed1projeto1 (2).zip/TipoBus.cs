using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;
using system IO;

namespace classes{
    public class tipoBus{
        public int Convencional ;
        public int Articulado ;
        private float tamConvencional ;
        private float tamConvencional ;

        public void setConvencional(string C){
            Convencional = C;
            C = 72;
        }
        public void setArticulado(string A){
            Articulado = A;
            A = 128;
        }
        private void settamConvencional(float compC){
            Convencional = compC;
            compC = 12.00;
        }
        private void settamArticulado(float ComA){
            Articulado = A;
            A = 23.5
        }

        public static List<tipoBus> leratipoBus(){
            var tipoBus = new List<tipoBus>();
            return tipoBus;
        }

        
    }
}
