using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

    class Frota{
        private int qtdFrota1;
        private int qtdfrota2;
        private int  qtdfrota3;
        private float qtdTanque;
        private float velocidade;
        public float validVelocidade;
        
    }
    public string setqtdFrota1(int F1){
        qtdFrota1 = F1;
        F1 =  600;
    }
    public void setqtdFrota2(int F2){
        qtdfrota2 = F2;
        F2 = 450;
    }
    public void setqtdFrota3(int F3){
        qtdfrota3 = F3;
        F3 = 350
    }
    public void set qtdTanque(float qt){
        qtdTanque = qt;
        qt = 120;
    }
    private void velocidade(float V){
        velocidade = v;
        v = 220;
    }
    public void validVelocidade(bool false){
        if(velocidade > 90){
            return "Velocidade Acima do Permitido"
        }
        else{
            // não retornar nenhuma mensagem!
        }
    }
}