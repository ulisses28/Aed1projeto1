using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;


namespace classedeOnibus{
// Levantamento do numero de usúarios do sistema de transporte de cada bairro,e os horarios com maior circulação de pessoas.
    class Onibus{
        private string cor_Bus;
        public bool portas;
        public float cartãoPassagem;
        private string nLinha;
        public float Passagem;
        
        private bool contrPortas;
        public float armazenaValor;
        public float Roleta;
        private bool validaCartão;
        public int qtdPessoas;

        }
        public void setPassagem(float P){
            Passagem = P;
            
        }
        // Atributo cor do onibus 
        private void setcor_Bus(string c){
            cor_Bus = c;
        }
        public void setportas(bool tP){
            tamanho = tP
        }
        private void setnLinha (string nl){
            nLinha = nl
        }
        public bool getcartãoPassagem(){
            float saldo = 175.60;
            if(_cartãoPassagem = saldo){
                return "Cartão recarregado";
            }
            else{
                return "Sem saldo";
            }
            
        }
        public void contrPortas(int TipoBus){
            if(qtdPessoas > convencional){
                return false;
            }
            else{
                return true;
                Console.WriteLine("Porta liberada");
            }
            if(qtdPessoas > Articulado){
                return false;
            }
            else{
                return true;
                console.WriteLine("Porta liberada");
            }
        }
        public void setroleta(float PagPassagem){

            if(roleta = valorPassagem){
                return true;
                qtdPessoas += 1;
            }
            else{
                return false
                //Aguardar o pagamento da passagem.
            }
            if(roleta = cartãoPassagem & cartãoPassagem == saldo & cartãoPassagem > 3.75){
                return true;
                cartãoPassagem -= Passagem;
                qtdPessoas += 1
                armazenaValor += Passagem;

            }
            else{
                return false
            }
            
        }
        // valadidando se existe saldo no cartão.
        public void getvalidaCartao(bool Vc){
            validaCartão = Vc;
            if(cartãoPassagem > 3.75 & cartãoPassagem == saldo){
                return true;
            }
            else{
                return false "Cartao sem saldo";
            }  
        }
        public static int qtdPessoas(){
            if(roleta = true){
                qtdPessoas += 1;
            }
            else{
                return false
            }
        }
        public float getarmazenavalor(){
            roleta == true;
            armazenaValor += Passagem;
        }
    }

}