# Aed1projeto1
Controle de Passageiros do Sistema Transcol
criar um sistema de controle de passageiros do transcol,visando reduzir as super lotações que acontecem no dia,apresentando soluções para o tal problema.
Controle de passageiros
A sociedade lhe dá com um problema,que segue com o passar dos anos,que é " a superlotação" do sistema de transporte coletivo do Espirito Santo.
A ideia é levantar uma solução para esse problema,logo de Antemão pensaríamos logo em aumentar a quantidade de linhas dos coletivos,mas é preciso fazer um levantamento ou mapeamento dos locais como bairros que tem uma maior massa de pessoas que usam o onibus,e os horarios em que tem maior circulação,por que se não for feito um mapeamento,poderiamos ter custos elevados e prejuisos de ambas as partes,tanto dos empresários como do governo.
Então a ideia é fazer um programa que de inicio fará um teste como mapeamento do fluxo de usúarios do sistema de transportes de toda grande vitoria,com a lista de todos os bairros onde passam as linhas de onibus e os horarios com maior fluxos de passageiros.
passos:
1-implementar um controlador de passageiros onde ira registar a entrada de cada passageiro pela porta ou atravez da roleta.
esse metodo sera o primeiro teste para viabilizar e calcular o fluxo de movimentação de passageiros nos bairros.
2 - levantar os bairros Onde se tem o maior numero de passageiros e quais os horarios de maior movimentação.
classe filha tera o metodo que chamará esses dados para sua classe e ira calcular e fazer a distribuição dos onibus mapeando os horarios e os bairros que necessitam de uma maior circulação de pessoas.
bairros que possuaem menor numero de circulação em mesmo horario dos bairros que tem maior circulação,teram uma redução da quantidade de linhas de transporte.
3- o algoritimo deve retornar o numero de passageiros de acordo com a quantidade de passagens computadas na roleta,para se ter uma base do fluxo de utilização do transporte.
4 usar o conceito de lista ou vetor para identificar o resultado de cada viagem quando o onibus tiver retornado ao terminal,e listar de ordem crescente da quantidade de pessoas.
5- usar esse metodo pode ajudar na viabilização de um dos problemas que os usuários do sistema de transporte coletivo enfretam todos os dias,a ideia não é apenas aumentar a quantidade de frota de onibus apenas,mas sim fazer um estudo para que possa mobilizar e migrar veiculos de forma que reduza o custo e quantidade de veiculos disponibilizado. mas quais os motivos disso?
 1 Contrato do sistema transcol com o governo,isso aumentaria os custo as empresas de onibus,sendo que os contratos de onibus não aumentaria.
 2 quantidade de veiculos circulando nas vias da cidade:impactos.
 *AUMENTO NO NUMERO DE ACIDENTES
 *ALTO INDICE DE ENGARRAFAMENTO,NOSSAS VIAS NÃO FORAM PROJETADAS PARA GRANDES QUANTIDADES DE VEICULOS,ASSIM COMO AS GRANDES METROPOLES.
 *AUMENTARIA A QUANTIDADE DE FUNCIONÁRIO E MANUNTENÇÃO NOS VEICULOS QUE TEM GRANDE CUSTO.
 *POLUIÇÃO SONORA EMITIDO DOS SOM DO RONCO DOS MOTORES E BUZINAS.
 *AUMENTO DA EMISSAO DE POLUENTES COMO MOXIDO DE CARBONO,DIOXIDOS E OUTROS GAZEZ POLUENTES,QUE SÃO EMITIDAS PELAS DISCARGAS DESSE VEICULOS,QUE PODEM CAUSAR IMPACTOS AMBIENTAS,ATMOSFERICOS,PROBLEMAS DE SAUDE COMO: RESPIRATORIO,AUDITIVO,VISUAL ENTRE OUTROS.
 RESUMO
 Então construir um projeto de forma que possa minimizar um problema,devemos pensar na melhor forma de fazer, fazer com o melhor caminho,menor custo e menor impacto ao meio ambiente e sociedade,a otimização dos processos podem retornar caminhos para se contruir uma sociedade melhor,pois algoritmos é a melhor caminho para encontrar a resposta e solução para os diversos problemas da sociedade,basta ter vontade e dedicação.
 Ass: Ulisses de Almeida

