using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

public class Onibus{
    private list<nome,cnpj,qtdFrota1> Empresa1();
    private list<nome,cnpj,qtdFrota2> Empresa2;
    private list<nome,cnpj,qtdFrota3> Empresa3;
    public int obterqtdPessoas;
    }
    public void  setEmpresa1(int Frota,string no,string cj){
        add.nome = no;
        add.cnpj = cj;
        add.Empresa1 = Frota1;;
    
    }
    public string getEmpresa1{
        return Empresa1;

    }
    public void  setEmpresa2(int Frota,string no,string cj){
        add.nome = no;
        add.cnpj = cj;
        add.Empresa1 = Frota1;;
    
    }
    public string getEmpresa2{
        return Empresa2;
    }
    public void  setEmpresa3(int Frota,string no,string cj){
        nome = no;
        cnpj = cj;
        Empresa1 = Frota1;;
    
    }
    public string getEmpresa3{
        return Empresa3;


    public int getobterPessoas(int Onibus){
        return qtdPessoas;
    }
}
