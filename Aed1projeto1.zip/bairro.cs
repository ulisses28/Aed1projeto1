using system;
namespace pesquisa_passageiros{
    class bairro{
        private double qtd_pessoas;
        public float h_circulacao;
        private float m_passagem
        public string n_bairro;
        public string municipio;    
  
    }
    private void setqtdpessoas(double qtdP){
         qtd_pessoas = qtdP;
         
    }
    public float seth_circulacao(){
        float distance = 100;
        float time = 1nim;
        float distance_inicial =0;
        float distance_final = 3000;
        if(distance =100){
            time +=1;
            time_total = time;
            return time_total; 
        }
    }
    private float setm_passagem(){
        float dinheiro = 3.75;
        float c_passag= saldo
        bool roleta
        if(roleta == dinheiro){
            return true;
            Console.ReadLine("Roleta liberada");
            qtd_pessoas += 1;
        }

        
    }
}